#!/bin/bash

cd .. && zip -r ./bsuid_program_languages/bsuid-pl.zip bsuid_program_languages/