#!/bin/bash

zip -r bsuid-pl.zip .